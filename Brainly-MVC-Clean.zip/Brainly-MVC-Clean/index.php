<?php
require_once __DIR__ . '/controllers/TarefaController.php';

$controller = new TarefaController();
$action = $_GET['action'] ?? 'index';

if ($action === 'crear') {
    $controller->crear();
} else {
    $controller->index();
}
