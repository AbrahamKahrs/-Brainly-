  <footer class="mt-12 bg-white border-t border-gray-200 py-6">
    <div class="max-w-[1280px] mx-auto px-4 sm:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500 gap-3">
      <div class="flex items-center gap-2">
        <span class="font-extrabold text-gray-900">MindSparks MVC</span>
        <span>— Estilo Brainly Simplificado (Sin Likes, Con Carrusel)</span>
      </div>
      <div>
        <span>&copy; <?php echo date('Y'); ?> Comunidad Escolar y Universitaria</span>
      </div>
    </div>
  </footer>

  <!-- Modal Crear Tarea -->
  <div id="modal-crear" class="fixed inset-0 z-50 bg-gray-900/60 backdrop-blur-sm hidden flex items-center justify-center p-4">
    <div class="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-gray-200 space-y-4">
      <div class="flex items-center justify-between border-b border-gray-100 pb-3">
        <h3 class="text-lg font-extrabold text-gray-900">Publicar Nueva Tarea</h3>
        <button onclick="document.getElementById('modal-crear').classList.add('hidden')" class="text-gray-400 hover:text-gray-600">
          <span class="material-symbols-outlined">close</span>
        </button>
      </div>

      <form action="index.php?action=crear" method="POST" class="space-y-4">
        <div>
          <label class="block text-sm font-bold text-gray-800 mb-1">Materia</label>
          <select name="materia" class="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm focus:outline-none focus:border-red-600">
            <option value="Matemáticas">Matemáticas</option>
            <option value="Física">Física</option>
            <option value="Química">Química</option>
            <option value="Programación">Programación</option>
            <option value="Historia">Historia</option>
            <option value="Biología">Biología</option>
          </select>
        </div>

        <div>
          <label class="block text-sm font-bold text-gray-800 mb-1">Título / Pregunta clave</label>
          <input name="titulo" required type="text" class="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm focus:outline-none focus:border-red-600" placeholder="Ej: ¿Cómo calcular la derivada de f(x)?" />
        </div>

        <div>
          <label class="block text-sm font-bold text-gray-800 mb-1">Descripción detallada</label>
          <textarea name="descripcion" required rows="4" class="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm focus:outline-none focus:border-red-600 resize-none" placeholder="Explica lo que necesitas o muestra tu avance..."></textarea>
        </div>

        <div class="flex justify-end gap-2 pt-2">
          <button type="button" onclick="document.getElementById('modal-crear').classList.add('hidden')" class="px-4 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-sm">Cancelar</button>
          <button type="submit" class="px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold text-sm shadow">Publicar Tarea</button>
        </div>
      </form>
    </div>
  </div>

</body>
</html>
