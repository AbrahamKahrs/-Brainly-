<!-- Carrusel de últimas 5 tareas subidas (Auto-giratorio) -->
<div class="mb-6 bg-gradient-to-r from-gray-900 via-slate-800 to-gray-900 text-white rounded-2xl p-5 shadow-lg relative overflow-hidden">
  <div class="flex items-center justify-between mb-3 border-b border-gray-700/60 pb-2">
    <div class="flex items-center gap-2">
      <span class="flex h-2.5 w-2.5 rounded-full bg-red-500 animate-pulse"></span>
      <span class="font-mono text-xs font-bold uppercase tracking-wider text-red-400">Últimas 5 Tareas Subidas</span>
    </div>
    <div class="flex items-center gap-2">
      <button id="carousel-prev" class="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
        <span class="material-symbols-outlined text-[18px]">chevron_left</span>
      </button>
      <button id="carousel-next" class="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors">
        <span class="material-symbols-outlined text-[18px]">chevron_right</span>
      </button>
    </div>
  </div>

  <!-- Items container -->
  <div id="carousel-container" class="relative min-h-[110px]">
    <?php if (!empty($ultimas5)): ?>
      <?php foreach ($ultimas5 as $idx => $item): ?>
        <div class="carousel-slide absolute inset-0 transition-opacity duration-500 flex flex-col justify-between <?php echo $idx === 0 ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'; ?>" data-index="<?php echo $idx; ?>">
          <div>
            <div class="flex items-center gap-2 text-xs font-mono mb-1">
              <span class="bg-red-500/20 text-red-300 border border-red-500/30 px-2 py-0.5 rounded uppercase font-bold"><?php echo htmlspecialchars($item['materia']); ?></span>
              <span class="text-gray-400">por <strong><?php echo htmlspecialchars($item['usuario']); ?></strong></span>
              <span class="text-amber-400 font-bold ml-auto">+<?php echo $item['puntos']; ?> pts</span>
            </div>
            <h3 class="text-base sm:text-lg font-bold text-white line-clamp-1 mt-1">
              <?php echo htmlspecialchars($item['titulo']); ?>
            </h3>
            <p class="text-xs sm:text-sm text-gray-300 line-clamp-2 mt-1">
              <?php echo htmlspecialchars($item['descripcion']); ?>
            </p>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else: ?>
      <p class="text-gray-400 text-sm">No hay tareas recientes.</p>
    <?php endif; ?>
  </div>

  <!-- Carousel Indicators -->
  <div class="flex items-center justify-center gap-1.5 mt-4 pt-2 border-t border-gray-800">
    <?php foreach ($ultimas5 as $idx => $item): ?>
      <button class="carousel-dot w-2 h-2 rounded-full transition-all <?php echo $idx === 0 ? 'bg-red-500 w-5' : 'bg-gray-600'; ?>" data-slide="<?php echo $idx; ?>"></button>
    <?php endforeach; ?>
  </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const slides = document.querySelectorAll('.carousel-slide');
  const dots = document.querySelectorAll('.carousel-dot');
  let currentIndex = 0;
  const total = slides.length;
  if (total <= 1) return;

  function showSlide(index) {
    slides.forEach((slide, i) => {
      if (i === index) {
        slide.classList.remove('opacity-0', 'pointer-events-none');
        slide.classList.add('opacity-100', 'pointer-events-auto');
      } else {
        slide.classList.remove('opacity-100', 'pointer-events-auto');
        slide.classList.add('opacity-0', 'pointer-events-none');
      }
    });

    dots.forEach((dot, i) => {
      if (i === index) {
        dot.classList.add('bg-red-500', 'w-5');
        dot.classList.remove('bg-gray-600');
      } else {
        dot.classList.remove('bg-red-500', 'w-5');
        dot.classList.add('bg-gray-600');
      }
    });
    currentIndex = index;
  }

  function nextSlide() {
    showSlide((currentIndex + 1) % total);
  }

  function prevSlide() {
    showSlide((currentIndex - 1 + total) % total);
  }

  document.getElementById('carousel-next')?.addEventListener('click', nextSlide);
  document.getElementById('carousel-prev')?.addEventListener('click', prevSlide);
  dots.forEach((dot, i) => dot.addEventListener('click', () => showSlide(i)));

  // Auto rotation every 4 seconds
  setInterval(nextSlide, 4000);
});
</script>
