<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>MindSparks / Brainly - Comunidad de Tareas</title>
  
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
  <script src="https://cdn.tailwindcss.com"></script>

  <style>
    ::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
    .carousel-item { transition: opacity 0.5s ease-in-out; }
  </style>
</head>
<body class="bg-[#F9FAFB] font-['Plus_Jakarta_Sans',sans-serif] text-gray-900 antialiased selection:bg-red-500 selection:text-white">

  <!-- HEADER STICKY -->
  <header class="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
    <div class="max-w-[1280px] mx-auto px-4 sm:px-8 py-3 flex flex-col gap-3">
      
      <div class="flex items-center justify-between gap-4">
        <!-- Logo -->
        <a href="index.php" class="flex items-center gap-2 shrink-0">
          <div class="w-9 h-9 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-md shadow-red-500/30">
            <span class="material-symbols-outlined text-[24px]">bolt</span>
          </div>
          <span class="text-xl text-gray-900 font-extrabold tracking-tight hidden sm:inline">
            Mind<span class="text-red-600">Sparks</span>
          </span>
        </a>

        <!-- Search Bar -->
        <form action="index.php" method="GET" class="flex-1 max-w-xl">
          <div class="relative flex items-center bg-gray-50 rounded-xl border border-gray-200 focus-within:border-red-600 focus-within:bg-white focus-within:ring-2 focus-within:ring-red-500/20 px-3 py-1.5 transition-all">
            <span class="material-symbols-outlined text-gray-400 mr-2 text-[20px]">search</span>
            <input 
              name="search"
              value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>"
              class="w-full bg-transparent text-sm text-gray-900 placeholder:text-gray-400 focus:outline-none" 
              placeholder="¿Qué quieres aprender o resolver hoy?" 
              type="text"
            />
            <button type="submit" class="hidden sm:inline-block text-xs font-bold text-red-600 px-2 py-1 bg-red-50 rounded hover:bg-red-100">Buscar</button>
          </div>
        </form>

        <!-- Right User / Quick Action -->
        <div class="flex items-center gap-3 shrink-0">
          <button onclick="document.getElementById('modal-crear').classList.remove('hidden')" class="flex items-center gap-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs sm:text-sm px-4 py-2 rounded-xl transition-all shadow-sm">
            <span class="material-symbols-outlined text-[18px]">add</span>
            <span>+ Preguntar</span>
          </button>

          <div class="hidden lg:flex items-center gap-1 bg-red-50 border border-red-200/60 px-3 py-1 rounded-full text-red-600 font-mono text-xs font-bold">
            <span class="material-symbols-outlined text-[16px]">bolt</span>
            <span>+420 pts</span>
          </div>
        </div>
      </div>

      <!-- Categories Nav -->
      <nav class="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 text-xs uppercase font-mono">
        <?php 
          $matActual = $_GET['materia'] ?? 'todas';
          $materias = ['todas' => 'Todas', 'matematicas' => 'Matemáticas', 'fisica' => 'Física', 'quimica' => 'Química', 'programacion' => 'Programación', 'historia' => 'Historia', 'biologia' => 'Biología'];
          foreach ($materias as $key => $label):
            $active = ($matActual === $key) ? 'bg-red-600 text-white font-bold' : 'bg-gray-100 text-gray-700 hover:bg-red-50 hover:text-red-600';
        ?>
          <a href="index.php?materia=<?php echo $key; ?>" class="px-3 py-1 rounded-full whitespace-nowrap transition-colors <?php echo $active; ?>">
            <?php echo $label; ?>
          </a>
        <?php endforeach; ?>
      </nav>

    </div>
  </header>
