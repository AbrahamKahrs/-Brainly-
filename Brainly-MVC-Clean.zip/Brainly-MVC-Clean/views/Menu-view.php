<?php require_once __DIR__ . '/layouts/header.php'; ?>

<main class="w-full pt-32 min-h-screen">
  <div class="max-w-[1280px] mx-auto px-4 sm:px-8">
    
    <!-- Carrusel de últimas 5 tareas -->
    <?php require_once __DIR__ . '/layouts/carrusel_demo.php'; ?>

    <!-- Layout principal 2 columnas -->
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      <!-- Columna Principal: Lista de Tareas (SIN LIKES) -->
      <section class="lg:col-span-8 flex flex-col gap-4">
        <div class="flex items-center justify-between">
          <h2 class="text-xl font-extrabold text-gray-900">Todas las Tareas Registradas</h2>
          <span class="text-xs text-gray-500 font-mono"><?php echo count($tarefas); ?> tareas encontradas</span>
        </div>

        <?php if (!empty($tarefas)): ?>
          <?php foreach ($tarefas as $t): ?>
            <article class="bg-white rounded-xl p-5 border border-gray-200 shadow-sm space-y-3 hover:shadow-md transition-shadow">
              
              <!-- Header de la card -->
              <div class="flex items-start justify-between gap-3">
                <div class="flex items-center gap-3">
                  <div class="w-9 h-9 rounded-full bg-red-100 text-red-700 flex items-center justify-center font-bold text-sm border border-red-200">
                    <?php echo strtoupper(substr($t['usuario'], 0, 1)); ?>
                  </div>
                  <div>
                    <div class="flex items-center gap-2">
                      <span class="font-bold text-sm text-gray-900"><?php echo htmlspecialchars($t['usuario']); ?></span>
                      <span class="text-xs font-mono px-2 py-0.5 rounded bg-red-50 text-red-600 border border-red-100 font-bold uppercase">
                        <?php echo htmlspecialchars($t['materia']); ?>
                      </span>
                    </div>
                    <span class="text-xs text-gray-400"><?php echo $t['fecha_creacion']; ?></span>
                  </div>
                </div>

                <span class="flex items-center gap-1 px-2.5 py-1 rounded-full bg-red-50 text-red-600 border border-red-100 text-xs font-mono font-bold">
                  <span class="material-symbols-outlined text-[15px]">bolt</span>
                  <span>+<?php echo $t['puntos']; ?> pts</span>
                </span>
              </div>

              <!-- Contenido -->
              <div>
                <h3 class="text-base sm:text-lg font-bold text-gray-900 mb-1">
                  <?php echo htmlspecialchars($t['titulo']); ?>
                </h3>
                <p class="text-sm text-gray-600 leading-relaxed">
                  <?php echo htmlspecialchars($t['descripcion']); ?>
                </p>
              </div>

              <!-- Acciones simplificadas (Sin Likes) -->
              <div class="flex items-center justify-between pt-3 border-t border-gray-100 text-xs text-gray-500">
                <span class="flex items-center gap-1 text-emerald-600 font-bold">
                  <span class="material-symbols-outlined text-[16px]">help</span>
                  <span>Pregunta Abierta</span>
                </span>

                <button onclick="document.getElementById('modal-crear').classList.remove('hidden')" class="px-3 py-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 font-bold transition-colors">
                  Responder esta duda
                </button>
              </div>

            </article>
          <?php endforeach; ?>
        <?php else: ?>
          <div class="bg-white p-8 rounded-xl border border-gray-200 text-center text-gray-500">
            No se encontraron tareas en esta categoría o búsqueda.
          </div>
        <?php endif; ?>
      </section>

      <!-- Sidebar lateral -->
      <aside class="lg:col-span-4 flex flex-col gap-4">
        <!-- Card de Meta Diaria -->
        <div class="bg-white rounded-xl p-5 border border-gray-200 shadow-sm space-y-3">
          <div class="flex items-start justify-between">
            <div>
              <span class="text-xs font-mono font-bold text-red-600 uppercase">Meta Diaria</span>
              <h4 class="font-extrabold text-gray-900 text-base">Ayuda a 3 compañeros</h4>
            </div>
            <span class="material-symbols-outlined text-red-600 text-[28px]">emoji_events</span>
          </div>
          <div class="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
            <div class="bg-red-600 h-full w-2/3"></div>
          </div>
          <p class="text-xs text-gray-500">Has ayudado en 2 de 3 preguntas hoy. ¡Faltan poco para +150 XP!</p>
        </div>

        <!-- Card Informática / Comunidad -->
        <div class="bg-white rounded-xl p-5 border border-gray-200 shadow-sm">
          <h4 class="font-extrabold text-gray-900 mb-2">Acerca de la plataforma</h4>
          <p class="text-xs text-gray-600 leading-relaxed">
            Sistema MVC limpio y optimizado con SQLite en PHP. Los me gusta han sido retirados para dar un enfoque 100% académico y colaborativo.
          </p>
        </div>
      </aside>

    </div>
  </div>
</main>

<?php require_once __DIR__ . '/layouts/footer.php'; ?>
