<?php
class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $dbPath = __DIR__ . '/../data/database.sqlite';
        $this->pdo = new PDO("sqlite:" . $dbPath);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $this->initDb();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance->pdo;
    }

    private function initDb() {
        $sql = "CREATE TABLE IF NOT EXISTS tarefas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            titulo TEXT NOT NULL,
            materia TEXT NOT NULL,
            descripcion TEXT NOT NULL,
            usuario TEXT DEFAULT 'Estudiante',
            puntos INTEGER DEFAULT 25,
            fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP
        )";
        $this->pdo->exec($sql);

        // Seed demo data if empty
        $stmt = $this->pdo->query("SELECT COUNT(*) as total FROM tarefas");
        if ($stmt->fetch()['total'] == 0) {
            $demoData = [
                ['¿Cómo resolver (3x^2 - 5x)/(2x + 1) en cálculo?', 'Matemáticas', 'Necesito el desarrollo paso a paso aplicando la regla del cociente antes de simplificar.', 'Valeria R.', 50],
                ['¿Cómo calcular la aceleración en plano inclinado a 30° con rozamiento?', 'Física', 'Tengo mu = 0.2 y peso m. ¿Cómo descompongo la fuerza normal correctamente?', 'Carlos M.', 35],
                ['Diferencia entre map() y List Comprehension en Python', 'Programación', '¿Cuál tiene mejor rendimiento y sigue los estándares PEP8 para transformar listas grandes?', 'Lucía T.', 20],
                ['Resumen de las causas principales de la Segunda Guerra Mundial', 'Historia', 'Busco los puntos clave económicos y geopolíticos para un esquema de estudio.', 'Mateo G.', 15],
                ['Paso a paso para balancear reacciones redox en medio ácido', 'Química', '¿Cómo asigno los números de oxidación en MnO4- + Fe2+ -> Mn2+ + Fe3+?', 'Sofía M.', 40],
                ['Estructura y función de la mitocondria en la célula eucariota', 'Biología', 'Explicación sencilla del ciclo de Krebs y producción de ATP para examen.', 'Bruno S.', 30]
            ];
            $insert = $this->pdo->prepare("INSERT INTO tarefas (titulo, materia, descripcion, usuario, puntos) VALUES (?, ?, ?, ?, ?)");
            foreach ($demoData as $row) {
                $insert->execute($row);
            }
        }
    }
}
