<?php
require_once __DIR__ . '/../models/TarefaModel.php';

class TarefaController {
    private $model;

    public function __construct() {
        $this->model = new TarefaModel();
    }

    public function index() {
        $search = $_GET['search'] ?? '';
        $materia = $_GET['materia'] ?? '';

        $ultimas5 = $this->model->getUltimasTarefas(5);
        $tarefas = $this->model->getTodasTarefas($search, $materia);

        require_once __DIR__ . '/../views/Menu-view.php';
    }

    public function crear() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titulo = trim($_POST['titulo'] ?? '');
            $materia = trim($_POST['materia'] ?? 'Matemáticas');
            $descripcion = trim($_POST['descripcion'] ?? '');
            
            if (!empty($titulo) && !empty($descripcion)) {
                $this->model->crearTarefa($titulo, $materia, $descripcion);
            }
        }
        header("Location: index.php");
        exit;
    }
}
