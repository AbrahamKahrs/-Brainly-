<?php
require_once __DIR__ . '/../config/database.php';

class TarefaModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance();
    }

    public function getUltimasTarefas($limit = 5) {
        $stmt = $this->db->prepare("SELECT * FROM tarefas ORDER BY fecha_creacion DESC, id DESC LIMIT :limit");
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getTodasTarefas($search = '', $materia = '') {
        $sql = "SELECT * FROM tarefas WHERE 1=1";
        $params = [];

        if (!empty($search)) {
            $sql .= " AND (titulo LIKE :search OR descripcion LIKE :search)";
            $params[':search'] = '%' . $search . '%';
        }

        if (!empty($materia) && $materia !== 'todas') {
            $sql .= " AND LOWER(materia) = LOWER(:materia)";
            $params[':materia'] = $materia;
        }

        $sql .= " ORDER BY id DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function crearTarefa($titulo, $materia, $descripcion, $usuario = 'Estudiante', $puntos = 25) {
        $stmt = $this->db->prepare("INSERT INTO tarefas (titulo, materia, descripcion, usuario, puntos) VALUES (?, ?, ?, ?, ?)");
        return $stmt->execute([$titulo, $materia, $descripcion, $usuario, $puntos]);
    }
}
